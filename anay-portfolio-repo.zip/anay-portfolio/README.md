# Anay Agrawal – Portfolio

Personal portfolio of Anay Agrawal, B.Tech CSE (Data Science) student at JSS University.

Single-page static site (HTML + CSS + a little JavaScript). No build step.

## Run locally
Open `index.html` in a browser.

## Deploy with GitHub Pages
Settings → Pages → Deploy from a branch → `main` / root.
